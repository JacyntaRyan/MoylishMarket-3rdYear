function goBack(){
	window.history.back();
}

function checkDelete(){
	if (confirm("Are you sure you want to delete this record?"))
		return true;
	else
		return false;
}
function checkArchive(){
	if (confirm("Are you sure you want add this record to archive?"))
		return true;
	else
		return false;
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('UserModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');
	}

	public function index()
	{	$data['user_name'] =$this->UserModel->getUserName();
		$this->load->view('index',$data);
	}
	public function logInView()
	{	$this->load->view('LogInForm');
	}
	public function adminHomeView()
	{	$this->load->view('AdminIndex');
	}
	public function regCust()
	{	$this->load->view('registerCustomerView');
	}

	function home() {
		//if the user is logged in
		if($this->session->userdata('user_logged_in')) {
			//get the session data
			$session_data = $this->session->userdata('user_logged_in');

			//get the username from the session and put it in $data
			$data['email'] = $session_data['email'];
			$data['user_name'] =$this->UserModel->getUserName();
			//load index/home view with the username included in $data
			$this->load->view('index', $data);
		}
		elseif($this->session->userdata('admin_logged_in')) {
			//get the session data
			$session_data = $this->session->userdata('admin_logged_in');
			//get the username from the session and put it in $data
			$data['email'] = $session_data['email'];
			$data['user_name'] =$this->UserModel->getAdminName();
			//load index/home view with the username included in $data
			$this->load->view('AdminIndex', $data);
		}
		else {
			//if no session, redirect to login page
			//$this->load->view('LogInForm');
			echo 'no session';
		}
	}

	function verify_login() {
		//set the validation rules for the login form
		//This code ensures that both the username and password
		//	are trimed of extra spaces at the beginning and end and	are required fields
		//The check_database function is also called
		//callback_ allows you to write your own form validation code
		if ($this->input->post('login')) {
			$this->form_validation->set_rules('email', 'Email', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');

			if ($this->form_validation->run() == false) {
				//validation failed -> display login form
				//$this->load->view('login_view');
				echo 'formvalidation failed';
			} else {
				//validation passed (inc a call to check_database() via a callback) -> display secret content
				redirect('UserController/home');
			}
		}
	}

	function check_database($password) {
		$userType = "";
		//only get here if form validation succeeded. now validate the users details against the DB
		$email = $this->input->post('email');
		//query the DB
		$result = $this->UserModel->login($email, $password);
		//if a valid user write their id & name to session data
		if($result) {
			$sess_array = array();
			foreach($result as $row) {
				$userType = $row->user_type;
				$remember = $this->input->post('remember_me');
				if($userType == 'A'){
					$sess_array = array(
						'id' => $row->id,
						'email' => $row->email
					);
					$this->session->set_userdata('admin_logged_in', $sess_array);

					if($remember) {
						setcookie ("loginId", $email, time()+ (10 * 365 * 24 * 60 * 60));
						setcookie ("loginPassword", $password,  time()+ (10 * 365 * 24 * 60 * 60));
					} else {
						setcookie ("loginId","");
						setcookie ("loginPassword","");
					}
				}
				elseif ($userType == 'C'){
				$sess_array = array(
					'id' => $row->id,
					'email' => $row->email

				);
					$this->session->set_userdata('user_logged_in', $sess_array);

					if($remember) {
						setcookie ("loginId", $email, time()+ (10 * 365 * 24 * 60 * 60));
						setcookie ("loginPassword", $password,  time()+ (10 * 365 * 24 * 60 * 60));
					} else {
						setcookie ("loginId","");
						setcookie ("loginPassword","");
					}
				}

			}
			//return true -> we have a valid user
			return true;
		}
		else {
			//return false ->we have an invalid user
			$this->form_validation->set_message('check_database', 'Invalid username or password');
			return false;
		}
	}

	function displaySessionData() {
		//$sessionData = $this->session->all_userdata();
		$sessionData = $this->session->userdata();
		//output should appear in view
		//its only here to keep the example concise
		echo "Data currently stored in the session<br>";
		echo "Session ID: " 			. session_id() 				. "<br>";
		echo "IP Address: " 			. $_SERVER['REMOTE_ADDR'] 	. "<br>";
		echo "User Agent Info: " 		. $this->input->user_agent(). "<br>";
		echo "UserID: " 				. $sessionData['id'] 		. "<br>";
		echo "Authors First Name: " 	. $sessionData['fname']  	. "<br>";
		echo "Authors Last Name: " 		. $sessionData['lname']  	. "<br>";
	}
	function logOutUser() {
		//unset the session data
		$this->session->unset_userdata('user_logged_in');
		//destroy the session
		$this->session->sess_destroy();
		//load the login page
		$this->load->view('logInForm');
	}
	function logOutAdmin() {
		//unset the session data
		$this->session->unset_userdata('admin_logged_in');
		//destroy the session
		$this->session->sess_destroy();
		//load the login page
		$this->load->view('logInForm');
	}

	public function registration(){
		if ($this->input->post('register')){


			//set validation rules
			$this->form_validation->set_rules('customerName', 'name ', 'required');
			$this->form_validation->set_rules('contactLName', 'contact last name ', 'required');
			$this->form_validation->set_rules('contactFName', ' contact first name', 'required');
			$this->form_validation->set_rules('phone', 'phone', 'required');
			$this->form_validation->set_rules('address1', 'address line 1', 'required');
			$this->form_validation->set_rules('address2', 'address line 2');
			$this->form_validation->set_rules('city', 'city', 'required');
			$this->form_validation->set_rules('postCode', 'post code', 'required');
			$this->form_validation->set_rules('country', 'country', 'required');
			$this->form_validation->set_rules('email', 'email', 'required');
			$this->form_validation->set_rules('password', 'password', 'required');

			//get values from post
			$customer['customer_name'] = $this->input->post('customerName');
			$customer['contact_last_name'] = $this->input->post('contactLName');
			$customer['contact_first_name'] = $this->input->post('contactFName');
			$customer['phone'] = $this->input->post('phone');
			$customer['address_line_1'] = $this->input->post('address1');
			$customer['address_line_2'] = $this->input->post('address2');
			$customer['country'] = $this->input->post('country');
			$customer['postal_code'] = $this->input->post('postCode');
			$customer['city'] = $this->input->post('city');
			$customer['email'] = $this->input->post('email');
			$hashedPassword = $this->input->post('password');
			$customer['password'] = MD5($hashedPassword);


			//check if the form has passed validation
			if (!$this->form_validation->run()){
				//validation has failed, load the form again
				$this->load->view('registerCustomerView', $customer);

				return;
			}

			//check if insert is successful
			if ($this->UserModel->regCustomer($customer)) {
				$data['message']="Registration has been successful";
				redirect('/userController/logInView', 'refresh');
			}
			else {
				$data['message']="Uh oh ... problem on insert";
			}

			//load the view to display the message
			$this->load->view('displayMessageView', $data);

			return;
		}
		$customer['customer_name'] = "";
		$customer['contact_last_name'] = "";
		$customer['contact_first_name'] = "";
		$customer['phone'] = "";
		$customer['address_line_1'] = "";
		$customer['address_line_2'] = "";
		$customer['country'] = "";
		$customer['email'] = "";
		$customer['password'] = "";
		$customer['postal_code'] = "";
		$customer['city'] = "";

		//load the form
		$this->load->view('registerCustomerView', $customer);
	}








}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class OrderController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('OrderModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');

	}

	public function index()
	{	$this->load->view('AdminIndex');
	}
	public function editOrder($order_number,$product_code)
	{	$data['order_info']= $this->OrderModel->changeOrder($order_number,$product_code);
		$this->load->view('amendOrderView',$data);////this is fine , checked array($data) contents
	}
	public function listOrders()
	{	$data['order_info']=$this->OrderModel->view_all_orders();
		$this->load->view('orderListView',$data);
	}

	public function updateOrder($order_number)
	{

		//set validation rules
		//$this->form_validation->set_rules('orderNumber', 'orderNumber ', 'readonly');
		//$this->form_validation->set_rules('orderDate', 'orderDate ', 'readonly');
		//$this->form_validation->set_rules('customerNumber', 'customerNumber', 'readonly');
		//$this->form_validation->set_rules('productCode', 'productCode', 'readonly');
		//$this->form_validation->set_rules('comments', 'comments', 'required');
		$this->form_validation->set_rules('status', 'status', 'required');
		$this->form_validation->set_rules('quantityOrdered', 'QuantityOrdered', 'required');
		$this->form_validation->set_rules('priceEach', 'priceEach', 'required');


		//get values from post
		//$order['orderNumber'] = $order_number;
		//$order['orderDate'] = $this->input->post('orderDate');
		//$order['customerNumber'] = $this->input->post('customerNumber');
		//$order['productCode'] =
		$order['status'] = $this->input->post('status');
		$order['comments'] = $this->input->post('comments');
		$order['quantityOrdered'] = $this->input->post('quantityOrdered');
		$order['priceEach'] = $this->input->post('priceEach');
		$productCode = $this->input->post('productCode');

		//check if the form has passed validation
		if (!$this->form_validation->run()){
			//validation has failed, load the form again
			echo ("update failed");
			//$this->load->view('amendOrderView');
			//return;
		}

		//check if update is successful
		if ($this->OrderModel->amendOrder($order,$productCode,$order_number)) {
			echo ("<pre><h4>&Tab;&Tab;&Tab; order ".$order_number."Amended!</h4></pre>");
			redirect('OrderController/listOrders');
		}
		else {

			$data['message']="<pre><h4>&Tab;&Tab;&Tab; Uh oh ... problem on update, please try again!</h4></pre>";
			$this->load->view('displayAdminMessageView', $data);
		}

	}

	public function viewUserOrders()
	{	$data['order_info']=$this->OrderModel->view_all_user_orders();


		$this->load->view('userOrderListView',$data);
	}
	public function cancelOrder($order_number)
	{
		if ($this->OrderModel->cancelOrder($order_number)) {
			echo ("<pre><h4>&Tab;&Tab;&Tab; order ".$order_number."Amended!</h4></pre>");
			redirect('OrderController/viewUserOrders');
		}
		else {

			$data['message']="<pre><h4>&Tab;&Tab;&Tab; Uh oh ... problem with cancel, please try again!</h4></pre>";
			$this->load->view('displayMessageView', $data);
		}

	}
}


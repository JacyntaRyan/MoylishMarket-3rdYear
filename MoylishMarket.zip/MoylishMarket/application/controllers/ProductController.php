<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProductController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('ProductModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');

	}

	public function index()
	{	$this->load->view('AdminIndex');
	}

	function searchProducts() {
		$data['product_info'] = $this->ProductModel->getSearchProduct($this->input->post('search'));
		$this->load->view('userProductListView', $data);
	}
	function searchAdminProducts() {
		$data['product_info'] = $this->ProductModel->getAdminSearchProduct($this->input->post('search'));
		$this->load->view('productListView', $data);
	}

	public function viewProduct($produce_code)
	{	$data['view_data']= $this->ProductModel->drilldown($produce_code);
		$this->load->view('ProductView', $data);
	}
	public function userProductDrilldown($produce_code)
	{	$data['view_data']= $this->ProductModel->drilldownForUser($produce_code);
		$this->load->view('userProductView', $data);
	}

	public function listProducts()
	{	$data['product_info']=$this->ProductModel->get_all_products();
		$this->load->view('productListView',$data);
	}
	public function listArchiveProducts()
	{	$data['product_info']=$this->ProductModel->get_archive_products();
		$this->load->view('productArchiveListView',$data);
	}
	public function userViewProducts()
	{	$data['product_info']=$this->ProductModel->view_all_products();
		$this->load->view('userProductListView',$data);
	}

	public function editProduct($produce_code)
	{	$data['product_data']= $this->ProductModel->drilldown($produce_code);
		$this->load->view('updateProductView',$data);
	}

	public function archiveProduct($produce_code)
	{
		$deletedRows = $this->ProductModel->archiveProductModel($produce_code);
		if ($this->db->affected_rows() == 1) {
			$data['message'] = "$deletedRows Product has been archived";
		} else {

			$data['message'] = "There was an error deleting the product with an produce_code of $produce_code";
		}



		$this->load->view('displayAdminMessageView', $data);

	}
	public function deleteProduct($produce_code)
	{
		$inCurrentOrders = $this->ProductModel->checkForOrders($produce_code);
		if(!$inCurrentOrders) {
			$deletedRows = $this->ProductModel->deleteProductModel($produce_code);
			if ($this->db->affected_rows() == 1) {
				$data['message'] = "<pre><h4>&Tab;&Tab;&Tab;$deletedRows Product has been deleted!</h4></pre>\"";
			} else {
				$data['message'] = "There was an error deleting the product with an produce_code of $produce_code";
			}
		}
		else{
			$data['message'] = "Cannot delete product with an produce_code of $produce_code ,Order has been made";
		}

		$this->load->view('displayAdminMessageView', $data);

	}

	public function updateProduct($produce_code)
	{	$pathToFile = $this->uploadAndResizeFile();
		$this->createThumbnail($pathToFile);

		//set validation rules
		$this->form_validation->set_rules('produceCode', 'product Code ', 'readonly');
		$this->form_validation->set_rules('description', 'Description ', 'required');
		$this->form_validation->set_rules('productLine', 'Product Line', 'required');
		$this->form_validation->set_rules('supplier', 'Supplier', 'required');
		$this->form_validation->set_rules('quantityInStock', 'quantity In Stock', 'required');
		$this->form_validation->set_rules('bulkBuyPrice', 'bulk Buy Price', 'required');
		$this->form_validation->set_rules('bulkSalePrice', 'bulk Sale Price', 'required');
		$this->form_validation->set_rules('availability', 'availability', 'required');


		//get values from post
		$aProduct['produceCode'] = $produce_code;
		$aProduct['availability'] = $this->input->post('availability');
		$aProduct['description'] = $this->input->post('description');
		$aProduct['productLine'] = $this->input->post('productLine');
		$aProduct['supplier'] = $this->input->post('supplier');
		$aProduct['quantityInStock'] = $this->input->post('quantityInStock');
		$aProduct['bulkBuyPrice'] = $this->input->post('bulkBuyPrice');
		$aProduct['bulkSalePrice'] = $this->input->post('bulkSalePrice');
		if($_FILES['userfile']['size'] > 0)
		{
			$aProduct['photo'] = $_FILES['userfile']['name'];

		}




		//check if the form has passed validation
		if (!$this->form_validation->run()){
			//validation has failed, load the form again
			$this->load->view('updateProductView', $aProduct);
			return;
		}


		//check if update is successful
		if ($this->ProductModel->updateProductModel($aProduct, $produce_code)) {
			redirect('ProductController/listProducts');
		}
		else {

			$data['message']="<pre><h4>&Tab;&Tab;&Tab; Uh oh ... problem on update, please try again!</h4></pre>";
			$this->load->view('displayAdminMessageView', $data);
		}

	}

	public function handleInsert(){
		if ($this->input->post('submitInsert')){


			//set validation rules
			$this->form_validation->set_rules('produceCode', 'product Code ', 'required');
			$this->form_validation->set_rules('description', 'description ', 'required');
			$this->form_validation->set_rules('productLine', 'Product Line', 'required');
			$this->form_validation->set_rules('supplier', 'supplier', 'required');
			$this->form_validation->set_rules('quantityInStock', 'quantity In Stock', 'required');
			$this->form_validation->set_rules('bulkBuyPrice', 'bulk Buy Price', 'required');
			$this->form_validation->set_rules('availability', 'Availability', 'required');
			$this->form_validation->set_rules('bulkSalePrice', 'bulk Sale Price', 'required');
			//$this->form_validation->set_rules('userfile', 'file', 'required');
			//check if the form has passed validation


			//get values from post
			$aProduct['produceCode'] = $this->input->post('produceCode');
			$aProduct['description'] = $this->input->post('description');
			$aProduct['productLine'] = $this->input->post('productLine');
			$aProduct['supplier'] = $this->input->post('supplier');
			$aProduct['quantityInStock'] = $this->input->post('quantityInStock');
			$aProduct['bulkBuyPrice'] = $this->input->post('bulkBuyPrice');
			$aProduct['bulkSalePrice'] = $this->input->post('bulkSalePrice');
			$aProduct['availability'] = $this->input->post('availability');
			$aProduct['photo'] = $_FILES['userfile']['name'];

			//check if the form has passed validation

			if (!$this->form_validation->run()){
				//validation has failed, load the form again
				$this->load->view('insertProductView', $aProduct);
				return;
			}
			if(!$_FILES['userfile']['size'] > 0)
			{

				$data['message']="<pre><h4>&Tab;&Tab;&Tab; Must upload image when adding products please try again!</h4></pre>";
				$this->load->view('displayAdminMessageView', $data);
				return;
			}

			$pathToFile = $this->uploadAndResizeFile();
			$this->createThumbnail($pathToFile);

			//check if insert is successful
			if ($this->ProductModel->insertProductModel($aProduct)) {
				$data['message']="<pre><h4>&Tab;&Tab;&Tab;&Tab;&Tab; The insert has been successful</h4></pre>";
			}
			else {
				$data['message']="Uh oh ... problem on insert";
			}

			//load the view to display the message
			$this->load->view('displayAdminMessageView', $data);

			return;
		}
		$aProduct['produceCode'] = "";
		$aProduct['description'] = "";
		$aProduct['productLine'] = "";
		$aProduct['quantityInStock'] = "";
		$aProduct['supplier'] = "";
		$aProduct['bulkBuyPrice'] = "";
		$aProduct['bulkSalePrice'] = "";
		$aProduct['availability'] = "";
		$aProduct['photo'] = "";

		//load the form
		$this->load->view('insertProductView', $aProduct);
	}

	function uploadAndResizeFile()
	{	//set config options for thumbnail creation
		$config['upload_path']='./assets/images/products/full/';
		$config['allowed_types']='gif|jpg|png';
		$config['max_size']='100';
		$config['max_width']='1024';
		$config['max_height']='768';

		$this->load->library('upload',$config);

		if (!$this->upload->do_upload())
			echo $this->upload->display_errors();
		//else
		//	echo 'upload done<br>';

		$upload_data = $this->upload->data();
		$path = $upload_data['full_path'];

		$config['source_image']=$path;
		$config['maintain_ratio']='FALSE';
		$config['width']='180';
		$config['height']='200';

		$this->load->library('image_lib',$config);
		if (!$this->image_lib->resize())
			echo $this->image_lib->display_errors();
		//else
			//echo 'image resized<br>';

		$this->image_lib->clear();
		return $path;
	}

	function createThumbnail($path)
	{	//set config options for thumbnail creation
		$config['source_image']=$path;
		$config['new_image']='./assets/images/products/thumbs/';
		$config['maintain_ratio']='FALSE';
		$config['width']='42';
		$config['height']='42';

		//load library to do the resizing and thumbnail creation
		$this->image_lib->initialize($config);

		//call function resize in the image library to physiclly create the thumbnail
		if (!$this->image_lib->resize()){
			$data['message']=$this->image_lib->display_errors();
			$this->load->view('displayAdminMessageView', $data);
		}

			//echo $this->image_lib->display_errors();
		//else
		//	echo 'thumbnail created<br>';
	}


	function addToWishlist($produceCode)
	{
		if($this->ProductModel->addItemToWishlist($produceCode)){
			$data['message']="<pre><h4>&Tab;&Tab;&Tab;added item to wishlist !</h4></pre>";

			$this->load->view('displayMessageView', $data);

			redirect('ProductController/viewWishlist');


		}
		else{
			$data['message']="<pre><h4>&Tab;&Tab;&Tab; Uh oh ... problem adding item to wishlist please try again!</h4></pre>";
			$this->load->view('displayMessageView', $data);
		}
	}
	function viewWishlist()
	{
		$data['product_info']=$this->ProductModel->view_wishlist();
		$this->load->view('viewWishlist',$data);
	}
	function removeFromWishList($produceCode)
	{
		if($this->ProductModel->remove_from_wishlist($produceCode))
		{
			redirect('ProductController/viewWishlist');
		}
	}

	function addToCart($produceCode)
	{
		if($this->ProductModel->addItemToCart($produceCode)){
			$data['message']="<pre><h4>&Tab;&Tab;&Tab;added item to Cart !</h4></pre>";

			$this->load->view('displayMessageView', $data);

			redirect('ProductController/viewCart');


		}
		else{
			$data['message']="<pre><h4>&Tab;&Tab;&Tab; Uh oh ... problem adding item to wishlist please try again!</h4></pre>";
			$this->load->view('displayMessageView', $data);
		}
	}
	function viewCart()
	{
		$data['product_info']=$this->ProductModel->view_cart();
		$this->load->view('viewCart',$data);
	}
	function removeFromCart($produceCode)
	{
		if($this->ProductModel->remove_from_cart($produceCode))
		{
			redirect('ProductController/viewCart');
		}
		redirect('ProductController/viewCart');
	}
	function buyNow()
	{
		$data['message']="<pre><h4>&Tab;&Tab;&Tab; Not implemented!</h4></pre>";
		$this->load->view('displayMessageView', $data);
	}

}

<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProductModel extends CI_Model
{
	function __construct()
	{	parent::__construct();
		$this->load->database();
	}

	function insertProductModel($products)
	{	$this->db->insert('products',$products);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	function getSearchProduct($searchProduct) {

		$this->db->select("produceCode,description,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");
		$this->db->from('products');
		$this->db->where('availability','y');
		$this->db->like('description', $searchProduct);
		$this->db->order_by('description');
		$query = $this->db->get();
		return $query->result();
	}
	function getAdminSearchProduct($searchProduct) {

		$this->db->select("produceCode,description,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");
		$this->db->from('products');
		$this->db->where('availability','y');
		$this->db->like('description', $searchProduct);
		$query = $this->db->get();
		return $query->result();
	}

	function get_all_products()
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");

		$this->db->from('products');
		$this->db->where('availability','y');
		$this->db->order_by('description');
		$query = $this->db->get();
		return $query->result();
	}
	function get_archive_products()
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");

		$this->db->from('products');
		$this->db->where('availability','n');
		$this->db->order_by('description');
		$query = $this->db->get();
		return $query->result();
	}
	public function checkForOrders($produce_code){
		$this->db->select("product_id");
		$this->db->from('check_orders');
		$this->db->where('product_id',$produce_code);
		$query = $this->db->get();
		$result = $query->result();
		if(!empty($result))
		{
			return true;
		}
		else{
			return false;
		}
	}

	public function deleteProductModel($produce_code)
	{
		$this->db->where('produceCode', $produce_code);
		$this->db->delete('products');

		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}
	public function archiveProductModel($produce_code)
	{
		$this->db->set('availability', 'n');
		$this->db->where('produceCode', $produce_code);
		$this->db->update('products');

		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	function updateProductModel($products,$produce_code)
	{	$this->db->where('produceCode', $produce_code);
		return $this->db->update('products', $products);
	}

	public function drilldown($produce_code)
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");
		$this->db->from('products');
		$this->db->where('produceCode',$produce_code);
		$query = $this->db->get();
		return $query->result();
	}
	public function drilldownForUser($produce_code)
	{	$this->db->select("produceCode,description,supplier,quantityInStock,bulkSalePrice,photo");
		$this->db->from('products');
		$this->db->where('produceCode',$produce_code);
		$query = $this->db->get();
		return $query->result();
	}

	function view_all_products()
	{	$this->db->select("produceCode,description,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,availability,photo");

		$this->db->from('products');
		$this->db->where('availability','y');
		$this->db->order_by('description');
		$query = $this->db->get();
		return $query->result();
	}

	public function addItemToWishlist($produceCode)
	{
		$sessionData = $this->session->userdata('user_logged_in');
		$data = array(
			'produce_code' => $produceCode,
			'customer_id' => $sessionData['id']

		);
		$this->db->insert('wish_list', $data);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	public function view_wishlist()
	{
		$sessionData = $this->session->userdata('user_logged_in');
		 $cust_num = $sessionData['id'];
		//join($table, $cond[, $type = ''[, $escape = NULL]])
		$cond = 'products.produceCode = wish_list.produce_code';
		$this->db->select("produceCode,description,supplier,bulkSalePrice,photo");
		$this->db->from('products');
		$this->db->join('wish_list',$cond);
		$this->db->where('customer_id',$cust_num);
		$query = $this->db->get();
		return $query->result();

	}

	public function remove_from_wishlist($produceCode)
	{

		$this->db->where('produce_code', $produceCode);
		$this->db->delete('wish_list');

		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	public function addItemToCart($produceCode)
	{
		$sessionData = $this->session->userdata('user_logged_in');
		$data = array(
			'product_id' => $produceCode,
			'customer_id' => $sessionData['id']

		);
		$this->db->insert('shopping_cart', $data);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	public function view_cart()
	{
		$sessionData = $this->session->userdata('user_logged_in');
		$cust_num = $sessionData['id'];
		//join($table, $cond[, $type = ''[, $escape = NULL]])
		$cond = 'products.produceCode = shopping_cart.product_id';
		$this->db->select("produceCode,description,supplier,bulkSalePrice,quantityInStock,photo");
		$this->db->from('products');
		$this->db->join('shopping_cart',$cond);
		$this->db->where('customer_id',$cust_num);
		$query = $this->db->get();
		return $query->result();

	}

	public function remove_from_cart($produceCode)
	{

		$this->db->where('product_id', $produceCode);
		$this->db->delete('shopping_cart');

		if ($this->db->affected_rows() >=1) {
			return true;
		}
		else {
			return false;
		}
	}


}
?>

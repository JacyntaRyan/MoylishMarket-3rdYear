<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class OrderModel extends CI_Model
{
	function __construct()
	{	parent::__construct();
		$this->load->database();
	}




	function amendOrder($order,$productCode,$order_number)
	{
		//$sql = "Update order JOIN orderdetails ON orders.orderNumber = orderdetails.orderNumber SET comments = ''";
		//$orderDetails = 'orderdetails';
		//$cond = 'orders.orderNumber = orderdetails.orderNumber';


		$comment = $order['comments'];
		$status = $order['status'];
		$quantityOrdered = $order['quantityOrdered'];
		$priceEach = $order['priceEach'];

		$this->db->set('comments',$comment);
		$this->db->set('status',$status);
		$this->db->where('orderNumber', $order_number);
		$this->db->update('orders');

		$this->db->set('priceEach',$priceEach);
		$this->db->set('quantityOrdered',$quantityOrdered);
		$this->db->where('orderNumber', $order_number);
		$this->db->where('productCode', $productCode);
		return $this->db->update('orderdetails');




		//$this->db->where('orderNumber', $order_number);
		//$this->db->where('productCode', $productCode);
		//$this->db->join($orderDetails,$cond , $type = 'inner', $escape = NULL);
		//$this->db->query($sql);
		//return $this->db->update('orders', $order);
		//return ($this->db->affected_rows() > 0);
	}

	public function changeOrder($order_number,$product_code)
	{	$this->db->select("orderNumber,orderDate,status,comments,customerNumber,productCode,quantityOrdered,priceEach");
		$this->db->from('orders_view');
		$this->db->where('orderNumber',$order_number);
		$this->db->where('productCode',$product_code);
		$this->db->order_by('orderDate DESC, orderNumber');
		$query = $this->db->get();
		return $query->result();
	}


	function view_all_orders()
	{	$this->db->select("orderNumber,orderDate,status,comments,customerNumber,productCode,quantityOrdered,priceEach");
		$this->db->from('orders_view');
		$this->db->order_by('orderDate DESC, orderNumber');
		$query = $this->db->get();
		return $query->result();
	}

	function view_all_user_orders()
	{
		$sessionData = $this->session->userdata('user_logged_in');
		$cust_num = $sessionData['id'];
		$this->db->select("orderNumber,orderDate,status,comments,customerNumber,productCode,quantityOrdered,priceEach");
		$this->db->from('orders_view');
		$this->db->where('customerNumber',$cust_num);
		$query = $this->db->get();
		return $query->result();
	}
	function cancelOrder($order_number)
	{
		$status = 'Cancelled';
		$this->db->set('status',$status);
		$this->db->where('orderNumber', $order_number);
		return $this->db->update('orders');
	}



}
?>


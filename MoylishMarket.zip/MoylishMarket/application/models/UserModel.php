<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class UserModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

//function to check if we have a valid user
	function login($email, $password)
	{
		$this->db->select('id, email, password,user_type');
		$this->db->from('log_in_details');
		$this->db->where('email', $email);
		$this->db->where('password', MD5($password));
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1)
			return $query->result();
		else
			return false;
	}

	function regCustomer($customer)
	{	$this->db->insert('customers',$customer);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}
	public function getUserName()
	{
		$sessionData = $this->session->userdata('user_logged_in');
		$custemail = $sessionData['email'];
		$this->db->select('customer_name');
		$this->db->from('customers');
		$this->db->where('email',$custemail);
		$query = $this->db->get();
		return $query->result();
	}
	public function getAdminName()
	{
		$sessionData = $this->session->userdata('admin_logged_in');
		$staffEmail = $sessionData['email'];
		$this->db->select('first_name');
		$this->db->from('staff');
		$this->db->where('email',$staffEmail);
		$query = $this->db->get();
		return $query->result();
	}

}

?>

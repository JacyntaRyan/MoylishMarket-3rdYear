

<?php
$this->load->view('userHeader');
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>

<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Fonts -->
	<link rel="dns-prefetch" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="css/style.css">

	<link rel="icon" href="Favicon.png">



	<title>Moylish Market</title>
</head>
<body>

<main class="login-form">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header"> </div>
					<div class="card-body">
						<form action="http://localhost/CIProjects/MoylishMarket/index.php/UserController/verify_login" method="post">
							<div class="form-group row">
								<label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
								<div class="col-md-6">
									<input type="text" id="email_address" class="form-control" name="email" value="<?php if(isset($_COOKIE["loginId"])) { echo $_COOKIE["loginId"]; } ?>"required autofocus>
								</div>
							</div>

							<div class="form-group row">
								<label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
								<div class="col-md-6">
									<input type="password" id="password" class="form-control" name="password" value="<?php if(isset($_COOKIE["loginPassword"])) { echo $_COOKIE["loginPassword"]; } ?>" required>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-md-6 offset-md-4">
									<div class="checkbox">
										<label>
											<input type="checkbox" name="remember_me" <?php if(isset($_COOKIE["loginId"])) { ?> checked="checked" <?php } ?>> Remember Me
										</label>
									</div>
								</div>
							</div>
							<div class="col-md-12 offset-md-2">
								<!--<button  onclick="  tag  php redirect('/userController/regCust', 'refresh'); ?>" >Register</button> -->
								<input type="submit" name="login" value="Login" class="btn btn-success btn-lg" id = 'log_in_btn'>
							</div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</div>

</main>







</body>
</html>

<?php
$this->load->view('footer');
?>

<?php
$this->load->view('header');
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>
	<br>
	<h1 class="main"> Insert Product </h1>
<?php echo form_open_multipart('ProductController/handleInsert');
echo '<br><br>';
echo '<label>ProduceCode :</label>';
echo form_input('produceCode', $produceCode);

echo '</br></br><label>Enter Description :</label>';
echo form_input('description', $description);

echo '</br></br><label>Enter product Line :</label>';
echo form_input('productLine', $productLine);

echo '</br></br><label>Enter supplier :</label>';
echo form_input('supplier', $supplier);

echo '</br></br><label>Bulk Buy Price :</label>';
echo form_input('bulkBuyPrice', $bulkBuyPrice);

echo '</br></br><label>Enter Bulk Sale Price :</label>';
echo form_input('bulkSalePrice', $bulkSalePrice);

echo '</br></br><label>quantity in stock :</label>';
echo form_input('quantityInStock', $quantityInStock);

echo '</br></br><label>availability :</label>';
echo form_input('availability', $availability);

echo '</br></br><label>Select File for Upload :</label>';
echo form_upload('userfile');

echo '</br></br>';

echo form_submit('submitInsert', "Submit!");

echo form_close();
echo validation_errors();
?>

<?php
$this->load->view('footer');
?>

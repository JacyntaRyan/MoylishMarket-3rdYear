<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
$cssbase = base_url()."assets/css/";
$jsbase = base_url()."assets/js/";
$img_base = base_url()."assets/images/";
$base = base_url() . index_page();
?>


<!DOCTYPE>
<html><head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>MoylishMarket</title>

	<link href="<?php echo $cssbase . "bootstrap.css"?>" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo $cssbase . "style.css"?>" rel="stylesheet" type="text/css" media="all" />
	<script src="<?php echo $jsbase."common.js"?>"></script>

</head>

<body>
<header>
	<img id="header_img" src="<?php echo $img_base . "site/logo.png"?>" />
	<nav id="myHeader" class="navbar navbar-expand-lg navbar-light bg-white ">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>



				<li class="nav-link ">
					<?php echo anchor('UserController/index','<span class="nav-link">Home</span>')?>
				</li>
				<li class = "nav-link">
					<?php echo anchor('ProductController/userViewProducts','<span class="nav-link">Browse Products</span>')?>
				</li>

		<?php
		if (!isset($_SESSION['user_logged_in'])){
		?>
				<li class="nav-link ">
						<?php echo anchor('UserController/logInView','<span class="nav-link">Log In</span>')?>
				</li>
				<li class="nav-link ">
					<?php echo anchor('UserController/registration','<span class="nav-link">Register</span>')?>
				</li>
		<?PHP } ?>
				<?php
				if (isset($_SESSION['user_logged_in'])){
				?>
				<li class="nav-link dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Account
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<?php echo anchor('ProductController/viewWishlist','<span class="dropdown-item">View Wish List</span>')?>
						<?php echo anchor('ProductController/viewCart','<span class="dropdown-item">View Cart</span>')?>
						<?php echo anchor('OrderController/viewUserOrders','<span class="dropdown-item">View Orders</span>')?>
						<?php echo anchor('UserController/logOutUser','<span class="dropdown-item">Log Out</span>')?>
					</div>
				</li>
				<?php } ?>

			</ul>
			<form class="form-inline my-6 my-lg-0" method = "POST" action="http://localhost/CIProjects/MoylishMarket/index.php/ProductController/searchProducts">
				<input id="search" class="form-control mr-sm-6" type="text" placeholder="Search" name = "search" aria-label="Search">
				<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
			</form>
		</div>
	</nav>





</header>





</body>


<?php
$this->load->view('header');
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>

	<br>

	<h1 class="main"> Amend Order </h1>


	<?php foreach ($order_info as $row) {
		echo form_open_multipart('OrderController/updateOrder/'.$row->orderNumber);
		echo '</br></br>';

		echo '</br></br><label>Order Number :</label>';
		echo form_input('orderNumber', $row->orderNumber);

		echo '</br></br><label>Order Date :</label>';


		echo form_input('orderDate', $row->orderDate);

		echo '</br></br><label>Order status :</label>';
		echo form_input('status', $row->status);

		echo '</br></br><label>Comments :</label>';
		echo form_input('comments', $row->comments);

		echo '</br></br><label>Customer ID :</label>';
		echo form_input('customerNumber', $row->customerNumber);

		echo '</br></br><label>Product ID :</label>';
		echo form_input('productCode', $row->productCode);

		echo '</br></br><label>Quantity Ordered :</label>';
		echo form_input('quantityOrdered', $row->quantityOrdered);

		echo '</br></br><label>Price :</label>';
		echo form_input('priceEach', $row->priceEach);


		echo '</br></br>';

		//}
		echo form_submit('submitUpdate', "Submit!");
		echo form_close();
		echo validation_errors();

}
?>

<?php
$this->load->view('footer');
?>


<?php
$this->load->view('userHeader');
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>



<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
<style>
	body {
		background-color: #edebf0;
	}
</style>
<div class="container">

	<form class="well form-horizontal" action="http://localhost/CIProjects/MoylishMarket/index.php/UserController/registration" method="post" enctype = "multipart/form-data" id="contact_form">
		<fieldset>

			<!-- Form Name -->
			<legend id ="registration_form" ><center><h2><b>Registration Form</b></h2></center></legend><br>

			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Business Name:</label>
				<div class="col-sm-10">
					<input  name="customerName" placeholder="Business/Customer Name" class="form-control"  type="text">
				</div>
			</div>

			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label" >Contact First Name:</label>
				<div class="col-sm-10">
					<input type="text" name="contactFName" placeholder="Contact First Name" class="form-control" >
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-8 col-form-label" >Contact Last Name</label>
				<div class="col-sm-10">
					<input type="text" name="contactLName" placeholder="Contact Last Name:" class="form-control"  >
				</div>
			</div>

			<!-- Text input-->
			<div class="form-group row">
				<label class="col-sm-8 col-form-label">E-Mail:</label>
				<div class="col-sm-10">
					<input type="text" name="email" placeholder="E-Mail Address" class="form-control" >
				</div>
			</div>


			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Contact No.</label>
				<div class="col-sm-10">
					<input type="text" name="phone" placeholder="xxxx-xxxxxx" class="form-control" >
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Address</label>
				<div class="col-sm-10">
					<input  name="address1" placeholder="Line 1" class="form-control"  type="text">
				</div>
			</div>

			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Address</label>
				<div class="col-sm-10">
					<input  name="address2" placeholder="Line 2" class="form-control"  type="text">
				</div>
			</div>

			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">City:</label>
				<div class="col-sm-10">
					<input  name="city" placeholder="City" class="form-control"  type="text">
				</div>
			</div>

			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Post Code</label>
				<div class="col-sm-10">
					<input  name="postCode" placeholder="Post code" class="form-control"  type="text">
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-8 col-form-label">Country</label>
				<div class="col-sm-10">

					<select name="country" class="form-control selectpicker">
						<option value="">Select Country</option>
						<option value = "Ireland">Republic of Ireland</option>
						<option value = "Northern Ireland">Northern Ireland</option>
						<option value = "England">England</option>
					</select>

				</div>
			</div>
			<!-- Text input-->

			<div class="form-group row">
				<label class="col-sm-8 col-form-label" >Password:</label>
				<div class="col-sm-10">
					<input name="password" placeholder="Password" class="form-control"  type="password">
				</div>
			</div>

			<!-- Button -->
			<div class="form-group row">
				<label class="col-sm-4 col-form-label"></label>
				<div class="col-sm-4"><br>
					<input type="submit" name="register" value="Register" class="btn btn-success btn-lg">
				</div>
			</div>

		</fieldset>
	</form>
</div>
</div><!-- /.container -->



<?php
echo validation_errors();
$this->load->view('footer');
?>




<?php
echo validation_errors();
$this->load->view('footer');
?>



<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->helper('url'); 
	$cssbase = base_url()."assets/css/";
	$jsbase = base_url()."assets/js/";
	$img_base = base_url()."assets/images/";
	$base = base_url() . index_page();
?>


<!DOCTYPE>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MoylishMarket</title>

<link href="<?php echo $cssbase . "bootstrap.css"?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo $cssbase . "style.css"?>" rel="stylesheet" type="text/css" media="all" />
<link href="https://fonts.googleapis.com/css?family=Heebo:300,400,500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
		  rel="stylesheet">
<script src="<?php echo $jsbase."common.js"?>"></script>

</head>

<body>
<header>
	<img id="header_img" src="<?php echo $img_base . "site/logo.png"?>" />
	<nav id="myHeader" class="navbar navbar-expand-lg navbar-light bg-white ">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item ">
        <?php echo anchor('UserController/adminHomeView','<span class="nav-link">Home</span>')?>
      </li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Products
			</a>
			<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				<?php echo anchor('ProductController/listProducts','<span class="dropdown-item">List All Products</span>')?>
				<?php echo anchor('ProductController/HandleInsert','<span class="dropdown-item">Add New Product</span>')?>
				<?php echo anchor('ProductController/listArchiveProducts','<span class="dropdown-item">Products Archive</span>')?>
			</div>
		</li>

		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Orders
			</a>
			<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				<?php echo anchor('OrderController/listOrders','<span class="dropdown-item">List All Orders</span>')?>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Account
			</a>
			<div class="dropdown-menu" aria-labelledby="navbarDropdown">
				
				<?php echo anchor('UserController/logOutAdmin','<span class="dropdown-item">Log Out</span>')?>
			</div>
		</li>
    </ul>
	  <form class="form-inline my-2 my-lg-0"  method = "POST" action="http://localhost/CIProjects/MoylishMarket/index.php/ProductController/searchAdminProducts">
		  <input class="form-control mr-sm-6" type="text" name = "search" placeholder="Search" aria-label="Search" >
		  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
	  </form>
  </div>
</nav>
	
	
	
	
  
</header>





</body>

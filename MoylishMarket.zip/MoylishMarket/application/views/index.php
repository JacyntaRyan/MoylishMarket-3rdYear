<?php
	$this->load->view('userHeader');
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

    <div class="main">
		<br><br><br><br>
		<br>
		<br>
		<?php
		if (isset($_SESSION['user_logged_in'])){
		?>
			<?php foreach($user_name as $row){?>
		<h1> Welcome Back <?php echo $row->customer_name ?></h1>
		<?php } }else{ ?>
			<h1>Welcome to Moylish Market </h1>
		<?php } ?>

		
		
		<br><br><br><br>
	</div>
	
<?php

	$this->load->view('footer'); 
?>

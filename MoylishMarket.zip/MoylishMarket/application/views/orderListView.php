<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('header');
$this->load->helper('url');
$this->load->helper('html');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
if (!isset($_SESSION['user_logged_in'])) {
	?>

	<?php if (empty($order_info)) {
		?>  <br><br><br><br><h2 class="main ">No Results Found</h2><?php
	} else {
		?>
		<div class="list">
			<br><br>
			<h1 class="main "></h1>
			<br><br>
		</div>
		<div class="container">


		<Table class="table table-light" id="order_table">
		<thead class="thead-light">
		<tr class="success">
			<td><h3>Customer Number</h3></td>
			<td><h3>Order Date </h3></td>
			<td><h3>Product Code</h3></td>
			<td><h3>Quantity Ordered</h3></td>
			<td><h3>Price Each</h3></td>
			<td><h3>Status </h3></td>
			<td><h3>Comments</h3></td>
			<td><h3></h3></td>
			<td><h3></h3></td>
		</tr>
		</thead>
		<tbody>

		<?php foreach ($order_info as $row) { ?>

			<tr class="success">

				<td><p><?php echo $row->customerNumber; ?></p></td>
				<td><p><?php echo $row->orderDate; ?></p></td>

				<!--				http://localhost/CIProjects/MoylishMarket/index.php/ProductController/editProduct/-->
				<td>
					<p><?php echo anchor('ProductController/editProduct/' . $row->productCode, $row->productCode); ?></p>
				</td>
				<td class="order-quantity"><p><?php echo $row->quantityOrdered; ?></p></td>
				<!-- Show two decimal places -->
				<td class="order-price-each"><span>&euro;</span>
					<p><?php echo number_format((float)($row->priceEach), 2, '.', '') ?></p></td>
				<td><p><?php echo $row->status; ?></p></td>
				<td><p><?php echo $row->comments; ?></p></td>
				<td><p>
						<i class="material-icons">edit</i><?php echo anchor('OrderController/editOrder/' . $row->orderNumber . '/' . $row->productCode, 'Amend'); ?>
				</td>
				<td></td>
			</tr>
		<?php }
	} ?>

	</tbody>
	</table>
	</div>

	<?php
	$this->load->view('footer');
}
?>


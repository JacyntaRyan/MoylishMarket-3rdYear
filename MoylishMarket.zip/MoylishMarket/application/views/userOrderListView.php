<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('userHeader');
$this->load->helper('url');
$this->load->helper('html');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>
<?php if(empty($order_info)) {
	?>  <br><br><br><br><h2 class="main ">No Results Found</h2><?php
}
else{
?>
	<div class="list">
		<br><br>
		<h1 class="main "></h1>
		<br><br>
	</div>
<div class="container">


	<Table class="table table-light" id = "order_table">
		<thead class="thead-light">
		<tr class = "success">
			<td><h3>Customer Number</h3></td>
			<td><h3>Order Number</h3></td>
			<td><h3>Order Date </h3></td>
			<td><h3>Product Code</h3></td>
			<td><h3>Quantity Ordered</h3></td>
			<td><h3>Price Each</h3></td>
			<td><h3>Status </h3></td>
			<td><h3>Comments</h3></td>
			<td><h3></h3></td>
			<td><h3></h3></td>
		</tr>
		</thead>
		<tbody>

		<?php foreach($order_info as $row){
			if(is_null($row))
			{
				$data['message']="<pre><h4>&Tab;&Tab;&Tab; You have no Orders</h4></pre>";
				$this->load->view('displayMessageView', $data);
			}?>

			<tr class = "success">

				<td ><p><?php echo $row->customerNumber;?></p></td>
				<td ><p><?php echo $row->orderNumber;?></p></td>
				<td ><p><?php echo $row->orderDate;?></p></td>
				<td ><p><?php echo $row->productCode;?></p></td>



				<td class="order-quantity"><p><?php echo $row->quantityOrdered;?></p></td>
				<!-- Show two decimal places -->
				<td class="order-price-each"><span>&euro;</span><p><?php echo number_format((float)($row->priceEach), 2, '.', '')?></p></td>
				<td ><p><?php echo $row->status;?></p></td>
				<td ><p><?php echo $row->comments;?></p></td>
				<?php if($row->status != 'Shipped' && $row->status != 'Cancelled'){?>
				<td ><p><i class="material-icons"></i><?php echo anchor('OrderController/cancelOrder/'.$row->orderNumber, '     Cancel Order'); ?> </td>
				<?php }else{?> <td></td><?php } ?>
				<td></td>
			</tr>
		<?php }}?>

		</tbody>
	</table>
</div>

<?php
$this->load->view('footer');
?>



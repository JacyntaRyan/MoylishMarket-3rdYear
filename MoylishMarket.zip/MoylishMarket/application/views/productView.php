<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>

<?php 
	foreach ($view_data as $row) {
		echo form_open();
		echo '</br></br>';

		echo 'Product Code :';
		echo form_input('produceCode', $row->produceCode, 'readonly');

		echo '</br></br>Description :';
		echo form_input('description', $row->description, 'readonly');

		echo '</br></br>productLine :';
		echo form_input('productLine', $row->productLine, 'readonly');

		echo '</br></br>Suplier :';
		echo form_input('suplier', $row->supplier, 'readonly');

		echo '</br></br>Quantity in Stock :';
		echo form_input('quantityInStock', $row->quantityInStock, 'readonly');

		echo '</br></br>Bulk Buy Price :';
		echo form_input('bulkBuyPrice', $row->bulkBuyPrice, 'readonly');

		echo '</br></br>Bulk Sale Price :';
		echo form_input('bulkSalePrice', $row->bulkSalePrice, 'readonly');

		echo '</br></br>Availability :';
		echo form_input('availability', $row->availability, 'readonly');

		echo '</br></br>';
		echo '<img src='. $img_base.'/products/full/'.$row->photo.'>';

		echo '</br></br>';
		echo form_close();
	}
?>

<?php
	$this->load->view('footer'); 
?>

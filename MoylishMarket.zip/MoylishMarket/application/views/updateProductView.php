<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<br>
<h1 class="main"> Update Product </h1>


<?php foreach ($product_data as $row) {
		echo form_open_multipart('ProductController/updateProduct/'.$row->produceCode);
		echo '</br></br>';
		echo '</br></br><label>Enter Description :</label>';
		echo form_input('description', $row->description);

		echo '</br></br><label>Enter product Line :</label>';
		echo form_input('productLine', $row->productLine);

		echo '</br></br><label>Enter supplier :</label>';
		echo form_input('supplier', $row->supplier);

		echo '</br></br><label>Bulk Buy Price :</label>';
		echo form_input('bulkBuyPrice', $row->bulkBuyPrice);

		echo '</br></br><label>Enter Bulk Sale Price :</label>';
		echo form_input('bulkSalePrice', $row->bulkSalePrice);

	echo '</br></br><label>Enter quantity in stock :</label>';
	echo form_input('quantityInStock', $row->quantityInStock);

		echo '</br></br><label>Enter availability :</label>';
		echo form_input('availability', $row->availability);

		echo '</br></br><label>Select File for Upload :</label>';
		echo form_upload('userfile');

		echo '</br></br>';
		echo form_submit('submitUpdate', "Submit!");
		echo form_close();
		echo validation_errors();
	//}
}
?>

<?php
	$this->load->view('footer'); 
?>

<?php
$this->load->view('userHeader');
$this->load->helper('url');
$this->load->library('session');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>

<?php
foreach ($view_data as $row) {
	echo form_open();
	echo '</br></br>';

	echo 'Product Code :';
	echo form_input('produceCode', $row->produceCode, 'readonly');

	echo '</br></br>Description :';
	echo form_input('description', $row->description, 'readonly');


	echo '</br></br>Supplier :';
	echo form_input('supplier', $row->supplier, 'readonly');

	echo '</br></br>Quantity in Stock :';
	echo form_input('quantityInStock', $row->quantityInStock, 'readonly');


	echo '</br></br>Bulk Sale Price :';
	echo form_input('bulkSalePrice', $row->bulkSalePrice, 'readonly');


	echo '</br></br>';
	echo '<img src=' . $img_base . '/products/full/' . $row->photo . '>';

	echo '</br></br>';
	if (isset($_SESSION['user_logged_in'])) {

		echo anchor('ProductController/addToCart/' . $row->produceCode, 'Add to cart', 'class="btn btn-success" id = cartBtn');
		echo anchor('ProductController/addToWishlist/' . $row->produceCode, 'Add to Wishlist', 'class="btn btn-success" id = wishlistBtn');
	}
	echo form_close();


	?>



<?php
}
?>


<?php
$this->load->view('footer');
?>


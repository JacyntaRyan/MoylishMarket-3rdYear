<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('userHeader');
$this->load->helper('url');
$this->load->helper('html');
$base = base_url() . index_page();
$img_base = base_url()."assets/images/";
?>
<?php if(empty($product_info)) {
	?>  <br><br><br><br><h2 class="main ">No Results Found</h2><?php
}
else{
?>
<div class="list">
	<br><br>
	<h1 class="main "></h1>
	<br><br>
</div>
<div class="container">


	<Table class="table" id = "product_table">
		<thead class="thead-light">
		<tr class = "success">
			<td><h3>Photo</h3></td>
			<td><h3>description</h3></td>
			<td><h3>supplier</h3></td>
			<td><h3>Price </h3></td>
			<td> </td>
			<td></td>

		</tr>
		</thead>
		<tbody>

		<?php foreach($product_info as $row){?>
			<tr class = "success">
				<td ><?php echo anchor('ProductController/userProductDrilldown/'.$row->produceCode, img($img_base.'products/thumbs/'.$row->photo)); ?></td>
				<td ><?php echo $row->description;?></td>
				<td ><?php echo $row->supplier;?></td>
				<td ><?php echo $row->bulkSalePrice;?></td>



				<?php
				if (isset($_SESSION['user_logged_in'])){
					?>
					<td><?php echo anchor('ProductController/addToCart/'.$row->produceCode, 'Add to Cart'); ?> </td>
					<td><?php echo anchor('ProductController/addToWishList/'.$row->produceCode, 'Add to wish list'); ?> </td>
				<?php } ?>
			</tr>
		<?php }}?>

		</tbody>
	</table>
</div>

<?php
$this->load->view('footer');
?>


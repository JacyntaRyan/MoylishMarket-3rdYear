<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('header'); 
	$this->load->helper('url');
	$this->load->helper('html');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<?php if(empty($product_info)) {
	?>  <br><br><br><br><h2 class="main ">No Results Found</h2><?php
}
else{
?>
	<div class="list">
		<br><br>
		<h1 class="main "></h1>
		<br><br>
	</div>
	<div class="container">


		<Table class="table table-light" id = "product_table">
			<thead class="thead-light">
			<tr class = "success">
				<td><h3>description</h3></td>
				<td><h3>supplier</h3></td>
				<td><h3>Price </h3></td>
				<td><h3>Photo</h3></td>
				<td><h3></h3></td>
				<td><h3></h3></td>
			</tr>
			</thead>
			<tbody>

			<?php foreach($product_info as $row){?>
				<tr class = "success">
					<td ><?php echo $row->description;?></td>
					<td ><?php echo $row->supplier;?></td>
					<td ><?php echo $row->bulkSalePrice;?></td>
					<td ><?php echo anchor('ProductController/viewProduct/'.$row->produceCode, img($img_base.'products/thumbs/'.$row->photo)); ?></td>
					<td><p><i class="material-icons">edit</i><?php echo anchor('ProductController/editProduct/'.$row->produceCode, 'Update'); ?></p> </td>
					<td><p><i class="material-icons">archive</i><?php echo anchor('ProductController/archiveProduct/'.$row->produceCode, 'Archive', 'onclick = "return checkArchive()"'); ?></p> </td>
				</tr>
			<?php }}?>

			</tbody>
		</table>
	</div>

<?php
	$this->load->view('footer'); 
?>
